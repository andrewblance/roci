.. Advent of Code documentation master file, created by
   sphinx-quickstart on Wed Dec  2 18:52:29 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Demo Code Documentation
==========================================

This is documention automatically generated using sphinx.

Look, a list:

 * Item one

Documentation for the Code
==========================
.. toctree::
   :maxdepth: 2
   :caption: Contents:

Codes pretty fun, right?


Week One Code
*************
.. autoclass:: src.day01.DayOne
    :members:

Indices and tables
******************
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
